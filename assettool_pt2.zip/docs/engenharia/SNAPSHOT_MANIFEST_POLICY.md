# Snapshot Manifest Policy

Stable project artifacts are certified; Python bytecode is not.

Excluded from `SNAPSHOT_SHA256SUMS.txt`:
- every path containing `__pycache__/`;
- every `*.pyc`;
- every `app/pt_build/` path.

All machine-local mutable state now lives under `app/pt_build/`, including generated asset registry files, local configuration, certification journals, caches and runtime evidence. `SNAPSHOT_MUTABLE_PATHS.txt` is therefore comment-only; it remains as an explicit policy marker, not as an allowlist for mutable files inside the static package.

`.pyc` files may change when unchanged Python sources are imported or tested, so their bytes are not a release-integrity signal. Source `.py` files remain hash-certified. `VERIFY_PACKAGE.sh` rejects future snapshot manifests that contain `__pycache__` or `.pyc`.

## Regeneração após mudança autorizada

Depois de concluir uma alteração intencional de código/documentação/estrutura, regenere a baseline atual com:

```bash
python3 app/update_snapshot_manifest.py --current-root .
```

O gerador exclui `.git/`, caches de ferramentas (`__pycache__/`, `.pytest_cache/`, `.mypy_cache/`, `.ruff_cache/`), `*.pyc`, qualquer `pt_build/`, o próprio `SNAPSHOT_SHA256SUMS.txt` e os paths declarados em `SNAPSHOT_MUTABLE_PATHS.txt`. Não regenere o manifest para esconder diferenças inesperadas; primeiro revise o diff.

<!-- PT_DOC_VALIDATION_SNAPSHOT_2026-09-25 -->

## Testes sem sujar bytecode

Durante pytest em uma árvore que será empacotada, prefira:

```bash
PYTHONDONTWRITEBYTECODE=1 "$PY" -m pytest -q dev_tests tests
```

Isso evita `.pyc` produzidos por imports normais. `python -m compileall`, por definição, gera bytecode; o estado gerado precisa ser removido pelo clean workflow antes de certificar o snapshot.

A política completa está em `VALIDACAO_TESTES_DESENVOLVIMENTO.md`.
