# Summit Tale — Semantic Asset Census V0.9.0

Client files scanned: **30073**
Scan errors: **0**
UI candidates: **6975**
Unknown semantic role: **1657**

## Semantic groups

| Group | Files |
|---|---:|
| MAP | 8651 |
| UI | 6975 |
| MONSTER | 3906 |
| PLAYER | 2405 |
| CONFIG | 2235 |
| EFFECT | 1702 |
| UNKNOWN | 1657 |
| NPC | 794 |
| ITEM | 608 |
| FRONTEND_SCENE | 580 |
| AUDIO | 437 |
| ANIMATION | 78 |
| EQUIPMENT | 45 |

## UI roles

| UI role | Files |
|---|---:|
| UI_ITEM_DROP_ART | 2320 |
| UI_OTHER | 2205 |
| UI_ITEM_ICON | 511 |
| UI_ITEM_ICON_WEAPON | 432 |
| UI_ITEM_ICON_DEFENSE | 429 |
| UI_FRONTEND | 271 |
| UI_ITEM_ICON_PREMIUM | 271 |
| UI_ITEM_ICON_ACCESSORY | 257 |
| UI_LOGIN | 155 |
| UI_HUD | 39 |
| UI_CHAT | 17 |
| UI_LOADING | 17 |
| UI_CHARACTER_STATUS | 13 |
| UI_TOOLTIP | 13 |
| UI_MAIN_BUTTON | 12 |
| UI_RESPAWN | 5 |
| UI_GAUGE | 4 |
| UI_SKILL | 4 |

## Physical families

| Family | Files |
|---|---:|
| BMP_STANDARD | 6781 |
| BMP_PROTECTED_HEADER14 | 5415 |
| SMD_MODEL_062 | 3751 |
| TGA_PROTECTED_FULL18 | 3038 |
| INX_CONFIG | 2098 |
| AUDIO | 2048 |
| TGA_STANDARD_HEADER | 1831 |
| EXT_PNG | 1350 |
| SMB_ANIMATION_CONTAINER | 960 |
| INF_CONFIG | 626 |
| EXT_SIN | 437 |
| EXT_PART | 337 |
| TEXT_OR_CONFIG | 279 |
| TGA_PROTECTED_FULL18_NO_FOOTER | 210 |
| EXT_MSG | 198 |
| EXT_DB | 189 |
| EXT_ASE | 103 |
| TGA_PROTECTED_KEEP_00_16 | 103 |
| SMD_STAGE_072 | 63 |
| EXT_LUA | 43 |
| TGA_PROTECTED_FULL18_TGA20_EXTENSION495 | 35 |
| NO_EXTENSION | 19 |
| EXT_CAB | 16 |
| EXT_CL | 14 |
| EXT_JPG | 12 |
| EXT_BGM | 11 |
| BMP_SHIP_DIB40_PROTECTED_EXACT | 10 |
| EXECUTABLE | 10 |
| EXT_LOG | 10 |
| TGA_ANOMALY_UNRESOLVED | 10 |
| EXT_PKG | 8 |
| EXT_REP | 8 |
| EXT_DAT | 6 |
| EXT_FNT | 5 |
| EXT_PSD | 5 |
| EXT_ZIF | 5 |
| SMD_MODEL_062_ALT_MAGIC_PROVEN_FAMILY | 5 |
| EXT_GPK | 4 |
| BMP_UNRESOLVED_BINARY_BMP_OUTLIER | 2 |
| EXT_CHT | 2 |

## Classification policy

- Path/layout evidence is preferred over filename guessing.
- Registry binding evidence enriches SMD/INX/SMB records but does not silently prove player-vs-monster runtime semantics.
- `UNKNOWN` is a valid result and is retained for later targeted discovery.
- This audit is read-only and does not authorize any new writer.
- UI is catalogued separately so the next milestone can add preview/edit support without rescanning the client.
