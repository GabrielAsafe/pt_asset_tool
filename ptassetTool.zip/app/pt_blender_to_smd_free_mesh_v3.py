#!/usr/bin/env python3
"""
PT SMD MODEL 0.62 — FREE MESH WRITER V3

Generic artist-oriented object writer for SMD Model 0.62.

Input requirements:
  - selected Blender mesh object may contain triangles/quads/ngons
  - 3..30000 vertices
  - 1..30000 faces
  - exactly one active UV layer
  - rigid Physique is serialized as one bone at weight 1.0 per vertex
  - bone names must exist in the supplied SMB skeleton
  - face material IDs must already exist in the selected source object

Crucially, this writer has NO old_to_new mapping and NO append-only rule.
Every smVERTEX record is rebuilt from Blender.
Every smFACE is rebuilt from Blender.
Every smTEXLINK is rebuilt from Blender.
Physique assignment policy is explicit: auto-repair (default), strict, or source-preserve.
Existing object-local ROT/POS/SCALE/TmPrevRot arrays are preserved byte-identical.

The pristine SMD is used only as a container/template for:
  - fixed smOBJ3D header fields not yet fully regenerated
  - material/face/TexLink record templates
  - material -> hTexture mapping
  - normal magnitude calibration
  - every non-target object block, kept byte-identical

It writes a NEW SMD only. It never writes the game client.
"""

import argparse
import hashlib
import json
import math
import statistics
import struct
import sys
from collections import defaultdict
from pathlib import Path

import bpy
import bmesh
from mathutils import Matrix, Vector

HEADER = b"SMD Model data Ver 0.62"
DEFAULT_TARGET = "MshC01"

SZ_HDR = 556
SZ_INFO = 40
SZ_OBJ = 2236
SZ_VERT = 24
SZ_FACE = 36
SZ_TEX = 32
SZ_ROT = 20
SZ_POS = 16
SZ_SCALE = 16
SZ_MATRIX = 64

O_VERTEX_PTR = 4
O_FACE_PTR = 8
O_TEX_PTR = 12
O_PHYS_PTR = 16
O_VERTEX_CAP = 76
O_FACE_CAP = 80
O_NV = 84
O_NF = 88
O_NT = 92
O_NAME = 172
O_PARENT = 204
O_TM = 240
O_NR = 684
O_NP = 688
O_NS = 692

F_TEX_PTR = 32
T_U = 0
T_V = 12
T_HTEX = 24
T_NEXT = 28

MAX_VERTICES = 30000
MAX_FACES = 30000


def i32(b, o):
    return struct.unpack_from("<i", b, o)[0]


def u32(b, o):
    return struct.unpack_from("<I", b, o)[0]


def cstr(b):
    return b.split(b"\0", 1)[0].decode("latin-1", errors="replace")


def sha(b):
    return hashlib.sha256(b).hexdigest()


def parse_file(data):
    if len(data) < SZ_HDR or not data.startswith(HEADER):
        raise ValueError("unexpected SMD/SMB header")

    n = i32(data, 24)
    if not 1 <= n <= 128:
        raise ValueError(f"implausible object count {n}")

    infos = []
    for idx in range(n):
        off = SZ_HDR + idx * SZ_INFO
        r = data[off:off + SZ_INFO]
        infos.append(dict(
            index=idx,
            table_off=off,
            name=cstr(r[:32]),
            length=i32(r, 32),
            start=i32(r, 36),
        ))

    for idx, inf in enumerate(infos):
        if inf["length"] <= 0:
            raise ValueError(f"{inf['name']}: bad object length")
        end = inf["start"] + inf["length"]
        if idx + 1 < len(infos):
            if end != infos[idx + 1]["start"]:
                raise ValueError(f"{inf['name']}: non-contiguous objects")
        elif end > len(data):
            raise ValueError("last object exceeds file")
        # Some physical Model0.62/SMB containers carry an opaque suffix after
        # the final object block.  Object table lengths remain authoritative;
        # writers must preserve this suffix byte-identically rather than
        # rejecting or interpreting it.
    return infos


def obj_layout(start, nv, nf, nt, nr, np, ns, phys):
    v = start + SZ_OBJ
    f = v + nv * SZ_VERT
    t = f + nf * SZ_FACE
    r = t + nt * SZ_TEX
    p = r + nr * SZ_ROT
    s = p + np * SZ_POS
    prev = s + ns * SZ_SCALE
    phy = prev + nr * SZ_MATRIX if phys else None
    end = phy + nv * 32 if phys else prev + nr * SZ_MATRIX
    return dict(
        vertices=v, faces=f, tex=t, rot=r, pos=p, scale=s,
        prev=prev, physique=phy, end=end
    )


def select_object_info(infos, name, object_index=None):
    hits = [x for x in infos if x["name"] == name]
    if object_index is not None:
        indexed = [x for x in hits if int(x["index"]) == int(object_index)]
        if len(indexed) != 1:
            raise ValueError(
                f"object {name!r} index={object_index} missing/mismatched; "
                f"matching_name_indices={[int(x['index']) for x in hits]}"
            )
        return indexed[0]
    if not hits:
        raise ValueError(f"object {name!r} missing")
    if len(hits) != 1:
        raise ValueError(
            f"object {name!r} is ambiguous across physical object-table "
            f"indices {[int(x['index']) for x in hits]}; supply --object-index"
        )
    return hits[0]


def parse_object(data, infos, name, object_index=None):
    inf = select_object_info(infos, name, object_index)

    raw = data[inf["start"]:inf["start"] + SZ_OBJ]
    if cstr(raw[O_NAME:O_NAME + 32]) != name:
        raise ValueError(f"{name}: NodeName mismatch")

    nv = i32(raw, O_NV)
    nf = i32(raw, O_NF)
    nt = i32(raw, O_NT)
    nr = i32(raw, O_NR)
    np = i32(raw, O_NP)
    ns = i32(raw, O_NS)
    phys = u32(raw, O_PHYS_PTR) != 0

    lay = obj_layout(inf["start"], nv, nf, nt, nr, np, ns, phys)
    if lay["end"] != inf["start"] + inf["length"]:
        raise ValueError(f"{name}: serialized length mismatch")

    verts = [
        struct.unpack_from("<6i", data, lay["vertices"] + i * SZ_VERT)
        for i in range(nv)
    ]

    faces = []
    for i in range(nf):
        off = lay["faces"] + i * SZ_FACE
        r = data[off:off + SZ_FACE]
        a, b, c, mat = struct.unpack_from("<4H", r, 0)
        faces.append(dict(
            raw=r, verts=(a, b, c), material=mat,
            lp_tex=u32(r, F_TEX_PTR)
        ))

    texlinks = []
    for i in range(nt):
        off = lay["tex"] + i * SZ_TEX
        r = data[off:off + SZ_TEX]
        texlinks.append(dict(
            raw=r,
            u=struct.unpack_from("<3f", r, T_U),
            v=struct.unpack_from("<3f", r, T_V),
            hTexture=u32(r, T_HTEX),
            NextTex=u32(r, T_NEXT),
        ))

    bones = []
    if phys:
        for i in range(nv):
            off = lay["physique"] + i * 32
            bones.append(cstr(data[off:off + 32]))

    return dict(
        info=inf, raw=raw, nv=nv, nf=nf, nt=nt,
        nr=nr, np=np, ns=ns, phys=phys, layout=lay,
        vertices=verts, faces=faces, texlinks=texlinks,
        bones=bones, texbase=u32(raw, O_TEX_PTR)
    )


def object_local_blob(data, obj):
    """Return the serialized object-local animation payload unchanged.

    Layout order is ROT, POS, SCALE, TmPrevRot[NumRot].  For Physique objects
    the blob ends where the Physique bone-name table begins; for static objects
    it extends to the object-block end.
    """
    lay = obj["layout"]
    end = lay["physique"] if obj.get("phys") else lay["end"]
    if end is None or end < lay["rot"]:
        raise ValueError("invalid object-local payload bounds")
    return bytes(data[lay["rot"]:end])


def parse_skeleton(data, *, allow_conflicting_duplicates=False):
    infos = parse_file(data)
    out = {}
    parents = {}
    source_indices = {}
    conflicts = []
    for inf in infos:
        raw = data[inf["start"]:inf["start"] + SZ_OBJ]
        name = cstr(raw[O_NAME:O_NAME + 32])
        parent = cstr(raw[O_PARENT:O_PARENT + 32])
        tm = struct.unpack_from("<16i", raw, O_TM)
        if name in out:
            if out[name] == tm and parents.get(name) == parent:
                # Physical legacy duplicate: same semantic bone repeated in the
                # container.  Collapse only byte/semantic-equivalent entries.
                continue
            if not allow_conflicting_duplicates:
                raise ValueError(f"duplicate skeleton node {name!r} with conflicting transform/parent")
            conflicts.append({
                "name": name,
                "first_index": int(source_indices.get(name, -1)),
                "duplicate_index": int(inf["index"]),
                "first_parent": str(parents.get(name) or ""),
                "duplicate_parent": parent,
            })
            # Rigid-only first-match support.  The caller must prove this name is
            # not directly referenced by the target object's Physique vertices.
            continue
        out[name] = tm
        parents[name] = parent
        source_indices[name] = int(inf["index"])
    if allow_conflicting_duplicates:
        return out, conflicts
    return out


def m(tm, r, c):
    return tm[(r - 1) * 4 + (c - 1)]


def world_fixed(local, tm):
    x, y, z = map(int, local)
    rx = x * m(tm, 1, 1) + y * m(tm, 2, 1) + z * m(tm, 3, 1)
    ry = x * m(tm, 1, 2) + y * m(tm, 2, 2) + z * m(tm, 3, 2)
    rz = x * m(tm, 1, 3) + y * m(tm, 2, 3) + z * m(tm, 3, 3)
    return (
        (rx >> 8) + m(tm, 4, 1),
        (ry >> 8) + m(tm, 4, 2),
        (rz >> 8) + m(tm, 4, 3),
    )


def _inverse_row3_matrix(tm):
    """Return the exact float inverse used by the legacy per-vertex fitter."""
    a, b, c = m(tm, 1, 1) / 256.0, m(tm, 1, 2) / 256.0, m(tm, 1, 3) / 256.0
    d, e, f = m(tm, 2, 1) / 256.0, m(tm, 2, 2) / 256.0, m(tm, 2, 3) / 256.0
    g, h, i = m(tm, 3, 1) / 256.0, m(tm, 3, 2) / 256.0, m(tm, 3, 3) / 256.0
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-12:
        raise ValueError("singular bone matrix")
    return (
        ((e * i - f * h) / det, (c * h - b * i) / det, (b * f - c * e) / det),
        ((f * g - d * i) / det, (a * i - c * g) / det, (c * d - a * f) / det),
        ((d * h - e * g) / det, (b * g - a * h) / det, (a * e - b * d) / det),
    )


def _apply_inverse_row3(vec, inv):
    x, y, z = vec
    return (
        x * inv[0][0] + y * inv[1][0] + z * inv[2][0],
        x * inv[0][1] + y * inv[1][1] + z * inv[2][1],
        x * inv[0][2] + y * inv[1][2] + z * inv[2][2],
    )


def inv_row3(vec, tm):
    return _apply_inverse_row3(vec, _inverse_row3_matrix(tm))


def prepare_fit_local(tm):
    """Precompute bone-invariant terms without changing fit semantics."""
    return {
        "inv": _inverse_row3_matrix(tm),
        "linear": (
            (m(tm, 1, 1), m(tm, 2, 1), m(tm, 3, 1)),
            (m(tm, 1, 2), m(tm, 2, 2), m(tm, 3, 2)),
            (m(tm, 1, 3), m(tm, 2, 3), m(tm, 3, 3)),
        ),
        "translation": (m(tm, 4, 1), m(tm, 4, 2), m(tm, 4, 3)),
    }


def inverse_point_prepared(world, prepared):
    tx, ty, tz = prepared["translation"]
    return _apply_inverse_row3(
        (world[0] - tx / 256.0, world[1] - ty / 256.0, world[2] - tz / 256.0),
        prepared["inv"],
    )


def inverse_point(world, tm):
    return inverse_point_prepared(world, prepare_fit_local(tm))


def fit_local_prepared(world, prepared, radius=4):
    """Exact legacy 9x9x9 search with precomputed matrix terms."""
    q = inverse_point_prepared(world, prepared)
    center = tuple(int(round(x * 256.0)) for x in q)
    best = None
    linear = prepared["linear"]
    tx, ty, tz = prepared["translation"]

    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                cand = (center[0] + dx, center[1] + dy, center[2] + dz)
                x, y, z = cand
                wf = (
                    ((x * linear[0][0] + y * linear[0][1] + z * linear[0][2]) >> 8) + tx,
                    ((x * linear[1][0] + y * linear[1][1] + z * linear[1][2]) >> 8) + ty,
                    ((x * linear[2][0] + y * linear[2][1] + z * linear[2][2]) >> 8) + tz,
                )
                represented = tuple(v / 256.0 for v in wf)
                err2 = sum((represented[k] - world[k]) ** 2 for k in range(3))
                score = (err2, cand)
                if best is None or score < best[0]:
                    best = (score, cand, represented)

    return best[1], best[2], math.sqrt(best[0][0])


def fit_local(world, tm, radius=4):
    # Compatibility wrapper for tests/tools that call the historical API.
    return fit_local_prepared(world, prepare_fit_local(tm), radius=radius)


def normalize(v):
    # PT_RC5_3_NESTED_VEC3_FIX
    if isinstance(v, (tuple, list)):
        if len(v) == 1 and isinstance(v[0], (tuple, list)) and len(v[0]) == 3:
            v = v[0]
        elif len(v) == 3 and all(isinstance(x, (tuple, list)) and len(x) == 1 for x in v):
            v = tuple(x[0] for x in v)
    # PT_RC6_1_VEC3_NUMERIC_LEAF_NORMALIZER
    # PT_RC6_5_MULTI_VEC3_DIRECTIONAL_CONSENSUS
    # RC6.1.2 proved that static writer callers can supply a list of vec3 values.
    # Collapse only when every non-zero vector is directionally equivalent.
    # Divergent loop/corner normals remain fail-closed to preserve hard-edge semantics.
    if isinstance(v, (list, tuple)) and len(v) > 1:
        _pt_rows = []
        _pt_rows_are_vec3 = True
        for _pt_row in v:
            if isinstance(_pt_row, (str, bytes, bytearray, dict)):
                _pt_rows_are_vec3 = False
                break
            try:
                _pt_vals = tuple(float(_pt_x) for _pt_x in _pt_row)
            except (TypeError, ValueError):
                _pt_rows_are_vec3 = False
                break
            if len(_pt_vals) != 3:
                _pt_rows_are_vec3 = False
                break
            _pt_rows.append(_pt_vals)
        if _pt_rows_are_vec3 and _pt_rows:
            _pt_units = []
            for _pt_r in _pt_rows:
                _pt_len2 = _pt_r[0]*_pt_r[0] + _pt_r[1]*_pt_r[1] + _pt_r[2]*_pt_r[2]
                if _pt_len2 > 1.0e-20:
                    _pt_len = math.sqrt(_pt_len2)
                    _pt_units.append((_pt_r[0]/_pt_len, _pt_r[1]/_pt_len, _pt_r[2]/_pt_len))
            if _pt_units:
                _pt_ref = _pt_units[0]
                _pt_max_delta = max(
                    max(abs(_pt_u[0]-_pt_ref[0]), abs(_pt_u[1]-_pt_ref[1]), abs(_pt_u[2]-_pt_ref[2]))
                    for _pt_u in _pt_units
                )
                if _pt_max_delta <= 1.0e-6:
                    _pt_sum = (
                        sum(_pt_r[0] for _pt_r in _pt_rows),
                        sum(_pt_r[1] for _pt_r in _pt_rows),
                        sum(_pt_r[2] for _pt_r in _pt_rows),
                    )
                    _pt_sum_len2 = _pt_sum[0]*_pt_sum[0] + _pt_sum[1]*_pt_sum[1] + _pt_sum[2]*_pt_sum[2]
                    if _pt_sum_len2 > 1.0e-20:
                        v = _pt_sum
                    else:
                        v = _pt_rows[0]
                else:
                    raise ValueError(
                        f'PT_RC6_5_MULTI_VEC3_DIVERGENT count={len(_pt_rows)} '
                        f'nonzero={len(_pt_units)} max_unit_component_delta={_pt_max_delta:.9g}'
                    )
            else:
                v = (0.0, 0.0, 0.0)

    _pt_stack = [v]
    _pt_v3 = []
    _pt_shape_trace = []
    while _pt_stack:
        _pt_item = _pt_stack.pop()
        try:
            _pt_scalar = float(_pt_item)
        except (TypeError, ValueError):
            if hasattr(_pt_item, 'x') and hasattr(_pt_item, 'y') and hasattr(_pt_item, 'z'):
                _pt_children = [_pt_item.x, _pt_item.y, _pt_item.z]
            elif isinstance(_pt_item, (str, bytes, bytearray, dict)):
                raise ValueError(f'PT_RC6_1_VEC3_NORMALIZE_FAIL nonnumeric={type(_pt_item).__name__} numeric_leaves={len(_pt_v3)} trace={_pt_shape_trace}')
            else:
                try:
                    _pt_children = list(_pt_item)
                except TypeError as _pt_exc:
                    raise ValueError(f'PT_RC6_1_VEC3_NORMALIZE_FAIL noniterable={type(_pt_item).__name__} numeric_leaves={len(_pt_v3)} trace={_pt_shape_trace}') from _pt_exc
                if not _pt_children:
                    raise ValueError(f'PT_RC6_1_VEC3_NORMALIZE_FAIL empty={type(_pt_item).__name__} numeric_leaves={len(_pt_v3)} trace={_pt_shape_trace}')
            _pt_shape_trace.append(f'{type(_pt_item).__name__}[{len(_pt_children)}]')
            if len(_pt_shape_trace) > 24:
                raise ValueError(f'PT_RC6_1_VEC3_NORMALIZE_FAIL excessive_nesting trace={_pt_shape_trace[:24]}')
            _pt_stack.extend(reversed(_pt_children))
        else:
            _pt_v3.append(_pt_scalar)
            if len(_pt_v3) > 3:
                raise ValueError(f'PT_RC6_1_VEC3_NORMALIZE_FAIL numeric_leaves_gt3 trace={_pt_shape_trace}')
    if len(_pt_v3) != 3:
        raise ValueError(f'PT_RC6_1_VEC3_NORMALIZE_FAIL numeric_leaves={len(_pt_v3)} trace={_pt_shape_trace}')
    v = tuple(_pt_v3)
    mag = math.sqrt(sum(x * x for x in v))
    if mag <= 1e-20:
        raise ValueError("zero-length normal")
    return tuple(float(x) / mag for x in v)


def build_export_triangles(mesh):
    """
    Build a non-destructive SMD triangle view.

    Already-triangulated meshes take a direct Mesh RNA fast path. This is
    semantically exact: no triangulation is required, polygon/loop order is
    preserved, and UV/material data is read from the same mesh storage already
    validated by ``require_uv_storage``. In particular this avoids entering
    Blender 5.2 BMesh triangulation for a no-op all-triangle mesh.

    Meshes containing any quad/ngon retain the established TEMP BMesh BEAUTY
    path. We intentionally do not replace that fallback with
    Mesh.calc_loop_triangles(): on the first artist-authored subdivided reference
    mesh it generated 69 zero-area triangles, while TEMP BMesh BEAUTY generated
    1292 triangles with zero degenerates and preserved all 656 vertices.
    """
    polygons = mesh.polygons
    if len(polygons) > 0 and all(int(poly.loop_total) == 3 for poly in polygons):
        uv_layer = mesh.uv_layers.active
        if uv_layer is None:
            raise ValueError("direct triangle path requires an active UV layer")
        uv_data = uv_layer.data
        vertex_count = len(mesh.vertices)
        out = []
        for fi, poly in enumerate(polygons):
            loop_indices = tuple(int(i) for i in poly.loop_indices)
            if len(loop_indices) != 3:
                raise ValueError(
                    f"direct triangle path polygon {fi}: expected 3 loops, "
                    f"got {len(loop_indices)}"
                )
            verts = tuple(int(mesh.loops[li].vertex_index) for li in loop_indices)
            if any(idx < 0 or idx >= vertex_count for idx in verts):
                raise ValueError(
                    f"direct triangle {fi}: vertex index out of range {verts}"
                )
            uvs = tuple(
                (float(uv_data[li].uv.x), float(uv_data[li].uv.y))
                for li in loop_indices
            )
            if not all(math.isfinite(u) and math.isfinite(v) for u, v in uvs):
                raise ValueError(f"direct triangle {fi}: non-finite UV {uvs}")
            out.append({
                "vertices": verts,
                "uvs": uvs,
                "polygon_index": int(poly.index),
                "source_polygon_size": 3,
                "material_index": int(poly.material_index),
            })
        if not out:
            raise ValueError("direct triangulated export view is empty")
        return out, {
            "method": "DIRECT_MESH_TRIANGLES",
            "source_vertices": vertex_count,
            "source_polygons": len(polygons),
            "export_triangles": len(out),
            "vertex_count_preserved": True,
            "artist_mesh_modified": False,
        }

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.verts.index_update()
        bm.faces.index_update()

        if len(bm.verts) != len(mesh.vertices):
            raise ValueError(
                f"temporary BMesh vertex count mismatch: "
                f"{len(bm.verts)} != {len(mesh.vertices)}"
            )

        uv_name = mesh.uv_layers.active.name if mesh.uv_layers.active else None
        uv_layer = bm.loops.layers.uv.get(uv_name) if uv_name else None
        if uv_layer is None:
            raise ValueError(
                f"temporary BMesh is missing active UV layer {uv_name!r}"
            )

        src_poly_layer = bm.faces.layers.int.new("pt_source_polygon")
        src_size_layer = bm.faces.layers.int.new("pt_source_polygon_size")
        for face in bm.faces:
            face[src_poly_layer] = int(face.index)
            face[src_size_layer] = int(len(face.verts))

        before_vertices = len(bm.verts)
        before_faces = len(bm.faces)

        bmesh.ops.triangulate(
            bm,
            faces=list(bm.faces),
            quad_method="BEAUTY",
            ngon_method="BEAUTY",
        )

        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.verts.index_update()
        bm.faces.index_update()

        if len(bm.verts) != before_vertices:
            raise ValueError(
                f"temporary triangulation changed vertex count: "
                f"{before_vertices} -> {len(bm.verts)}"
            )

        out = []
        for fi, face in enumerate(bm.faces):
            if len(face.verts) != 3 or len(face.loops) != 3:
                raise ValueError(
                    f"temporary triangulation left non-triangle face {fi}"
                )

            verts = tuple(int(v.index) for v in face.verts)
            if any(idx < 0 or idx >= len(mesh.vertices) for idx in verts):
                raise ValueError(
                    f"temporary triangle {fi}: vertex index out of range {verts}"
                )

            uvs = tuple(
                (float(loop[uv_layer].uv.x), float(loop[uv_layer].uv.y))
                for loop in face.loops
            )

            if not all(
                math.isfinite(u) and math.isfinite(v)
                for u, v in uvs
            ):
                raise ValueError(
                    f"temporary triangle {fi}: non-finite UV {uvs}"
                )

            out.append({
                "vertices": verts,
                "uvs": uvs,
                "polygon_index": int(face[src_poly_layer]),
                "source_polygon_size": int(face[src_size_layer]),
                "material_index": int(face.material_index),
            })

        if not out:
            raise ValueError("temporary triangulated export view is empty")

        return out, {
            "method": "TEMP_BMESH_BEAUTY",
            "source_vertices": before_vertices,
            "source_polygons": before_faces,
            "export_triangles": len(out),
            "vertex_count_preserved": len(bm.verts) == before_vertices,
            "artist_mesh_modified": False,
        }
    finally:
        bm.free()


def _source_world_direction(local_normal, tm):
    x, y, z = map(float, local_normal)
    return Vector((
        x * m(tm, 1, 1) + y * m(tm, 2, 1) + z * m(tm, 3, 1),
        x * m(tm, 1, 2) + y * m(tm, 2, 2) + z * m(tm, 3, 2),
        x * m(tm, 1, 3) + y * m(tm, 2, 3) + z * m(tm, 3, 3),
    ))


def _legacy_source_degenerate(src_obj, skeleton, tri):
    """Return True only when this exact source polygon was already degenerate.

    ``pt_source_polygon`` survives the temporary BMesh triangulation and is the
    provenance key.  Matching the same source face and the same vertex IDs means
    an edited mesh may preserve a shipped degeneracy, but it may never create a
    new degenerate topology and have it silently accepted.
    """
    pi = int(tri.get("polygon_index", -1))
    if not (0 <= pi < len(src_obj.get("faces") or [])):
        return False
    source_face = src_obj["faces"][pi]
    ids = tuple(int(x) for x in tri.get("vertices") or ())
    source_ids = tuple(int(x) for x in source_face.get("verts") or ())
    if len(ids) != 3 or sorted(ids) != sorted(source_ids):
        return False
    if int(tri.get("material_index", -1)) != int(source_face.get("material", -2)):
        return False
    points=[]
    for vi in source_ids:
        if not (0 <= vi < len(src_obj.get("vertices") or [])):
            return False
        bone = src_obj.get("bones", [])[vi] if src_obj.get("phys") else None
        if not bone or bone not in skeleton:
            return False
        local = src_obj["vertices"][vi][:3]
        points.append(Vector(world_fixed(local, skeleton[bone])))
    n=(points[1]-points[0]).cross(points[2]-points[0])
    return n.length <= 1e-12


def equal_normals(mesh, export_triangles, *, src_obj=None, skeleton=None, bones=None):
    acc = [Vector((0.0, 0.0, 0.0)) for _ in mesh.vertices]
    cnt = [0] * len(mesh.vertices)
    export_incident = [0] * len(mesh.vertices)
    legacy_degenerate = []

    source_incident = None
    if src_obj is not None:
        source_incident = [0] * int(src_obj.get("nv") or 0)
        for face in (src_obj.get("faces") or []):
            for raw_vi in (face.get("verts") or ()):
                vi = int(raw_vi)
                if 0 <= vi < len(source_incident):
                    source_incident[vi] += 1

    for fi, tri in enumerate(export_triangles):
        ids = tri["vertices"]
        for vi in ids:
            if not (0 <= vi < len(export_incident)):
                raise ValueError(f"export triangle {fi}: invalid vertex index {vi}")
            export_incident[vi] += 1
        a, b, c = [Vector(mesh.vertices[v].co) for v in ids]
        n = (b - a).cross(c - a)
        if n.length <= 1e-12:
            if src_obj is None or skeleton is None or not _legacy_source_degenerate(src_obj, skeleton, tri):
                raise ValueError(
                    f"export triangle {fi} / polygon {tri['polygon_index']}: "
                    "degenerate triangle not present in source"
                )
            legacy_degenerate.append({"export_triangle":fi,"source_polygon":int(tri["polygon_index"]),"vertices":list(ids)})
            continue
        n.normalize()
        for vi in ids:
            acc[vi] += n
            cnt[vi] += 1

    out = []
    fallback_vertices=[]
    preserved_zero_unreferenced=[]
    for vi, n in enumerate(acc):
        if cnt[vi] == 0 or n.length <= 1e-12:
            if src_obj is None or skeleton is None or bones is None or not (0 <= vi < int(src_obj.get("nv") or 0)):
                raise ValueError(f"vertex {vi}: no geometric normal")
            bone=str(bones[vi])
            if bone not in skeleton or vi >= len(src_obj.get("bones") or []) or str(src_obj["bones"][vi]) != bone:
                raise ValueError(f"vertex {vi}: legacy-degenerate normal fallback lacks exact source bone provenance")
            source_normal=src_obj["vertices"][vi][3:6]
            n=_source_world_direction(source_normal,skeleton[bone])
            if n.length <= 1e-12:
                source_is_exact_zero = all(int(x) == 0 for x in source_normal)
                source_refs = source_incident[vi] if source_incident is not None and vi < len(source_incident) else None
                export_refs = export_incident[vi]
                if source_is_exact_zero and source_refs == 0 and export_refs == 0:
                    # RC6.12 orphan-vertex compatibility: an exact shipped zero
                    # normal may be preserved only when the vertex is unused by
                    # every source face and remains unused by every export face.
                    # This cannot affect rendered triangle normals and does not
                    # permit zero normals on any referenced geometry.
                    out.append((0.0, 0.0, 0.0))
                    preserved_zero_unreferenced.append(vi)
                    continue
                raise ValueError(f"vertex {vi}: source normal is zero in legacy-degenerate fallback")
            fallback_vertices.append(vi)
        n.normalize()
        out.append((float(n.x), float(n.y), float(n.z)))
    return out, {
        "legacy_source_degenerate_triangles":legacy_degenerate,
        "legacy_source_degenerate_count":len(legacy_degenerate),
        "source_normal_fallback_vertices":fallback_vertices,
        "source_zero_normal_unreferenced_vertices":preserved_zero_unreferenced,
    }


def rigid_bone_rows(obj, vi):
    rows = []
    for e in obj.data.vertices[vi].groups:
        if e.weight <= 1e-8:
            continue
        if not (0 <= e.group < len(obj.vertex_groups)):
            raise ValueError(f"vertex {vi}: invalid vertex group index")
        rows.append((obj.vertex_groups[e.group].name, float(e.weight)))
    return rows


def rigid_bone(obj, vi):
    rows = rigid_bone_rows(obj, vi)
    if len(rows) != 1 or abs(rows[0][1] - 1.0) > 1e-5:
        raise ValueError(
            f"vertex {vi}: expected exactly one rigid group at weight 1.0; got {rows}"
        )
    return rows[0][0]


def _source_physique_position_map(src_obj, skeleton):
    """Map shipped bind-pose positions to their original Physique bones.

    Blender can split one shipped vertex into several vertices while preserving
    the exact bind-pose position (for example after artist topology/UV work).
    Those expanded vertices no longer have a usable source index, but their
    position still provides strong provenance for the original rigid bone.
    """
    out = defaultdict(list)
    source_bones = list(src_obj.get("bones") or [])
    for source_vi, sv in enumerate(src_obj.get("vertices") or []):
        if source_vi >= len(source_bones):
            continue
        bone = str(source_bones[source_vi] or "")
        if not bone or bone not in skeleton:
            continue
        fixed = world_fixed(sv[:3], skeleton[bone])
        pos = tuple(float(x) / 256.0 for x in fixed)
        key = tuple(round(x, 6) for x in pos)
        out[key].append((bone, int(source_vi), pos))
    return out


def _source_bone_for_blender_vertex(obj, vi, *, src_obj, skeleton, position_map):
    source_bones = list(src_obj.get("bones") or [])
    source_nv = int(src_obj.get("nv") or len(src_obj.get("vertices") or []))
    # When topology/indexing is unchanged, the physical index is the strongest
    # correspondence available and remains valid even after moving the vertex.
    if len(obj.data.vertices) == source_nv and vi < len(source_bones):
        bone = str(source_bones[vi] or "")
        if bone in skeleton:
            return bone, "source_index_correspondence", int(vi)

    world = tuple(float(x) for x in obj.data.vertices[vi].co)
    key = tuple(round(x, 6) for x in world)
    rows = list(position_map.get(key) or [])
    if not rows:
        return None, None, None

    blender_groups = {name for name, weight in rigid_bone_rows(obj, vi) if weight > 1e-8}
    matching = [row for row in rows if row[0] in blender_groups]
    pool = matching or rows
    unique_bones = sorted({row[0] for row in pool}, key=lambda x: (x.casefold(), x))
    if len(unique_bones) != 1:
        return None, None, None
    bone = unique_bones[0]
    source_vi = next(row[1] for row in pool if row[0] == bone)
    return bone, "source_position_correspondence", int(source_vi)


def auto_rigid_bone(
    obj, vi, *, seed_material, skeleton, conflict_keys, source_bone=None,
    source_strategy=None, source_vertex=None,
):
    """Choose one serializable rigid bone and report any automatic repair.

    Repair priority is provenance first, artist intent second, deterministic
    fallback last:
      1. use a verified source/index or source/position correspondence when that
         original bone is still one of the Blender vertex groups;
      2. use a unique highest Blender weight;
      3. stable pseudo-random choice only for a true tie/ambiguous remainder.

    Model0.62 still serializes exactly one Physique bone at weight 1.0.
    """
    rows = rigid_bone_rows(obj, vi)
    strict = len(rows) == 1 and abs(rows[0][1] - 1.0) <= 1e-5
    if strict:
        return rows[0][0], None

    candidates = [
        (name, weight) for name, weight in rows
        if name in skeleton and name.casefold() not in conflict_keys
    ]
    candidate_names = {name for name, _ in candidates}
    selected = None
    strategy = None

    if source_bone and source_bone in candidate_names:
        selected = str(source_bone)
        strategy = str(source_strategy or "source_correspondence")
    elif candidates:
        max_weight = max(weight for _, weight in candidates)
        strongest = sorted(
            [name for name, weight in candidates if abs(weight - max_weight) <= 1e-8],
            key=lambda x: (x.casefold(), x),
        )
        if len(strongest) == 1:
            selected = strongest[0]
            strategy = "highest_blender_weight"
        else:
            canonical = sorted(candidates, key=lambda row: (row[0].casefold(), row[0], row[1]))
            payload = (
                str(seed_material) + "|" + str(vi) + "|"
                + "|".join(f"{name}:{weight:.17g}" for name, weight in canonical)
            ).encode("utf-8", "surrogatepass")
            digest = hashlib.sha256(payload).digest()
            selected = canonical[int.from_bytes(digest[:8], "big") % len(canonical)][0]
            strategy = "stable_pseudorandom_tie_break"
    elif source_bone and source_bone in skeleton and source_bone.casefold() not in conflict_keys:
        selected = str(source_bone)
        strategy = "source_fallback_no_valid_blender_group"
    else:
        raise ValueError(
            f"vertex {vi}: automatic rigid-weight repair found no valid bone; got {rows}"
        )

    repair = {
        "vertex": int(vi),
        "original_weights": [[name, weight] for name, weight in rows],
        "selected_bone": selected,
        "serialized_weight": 1.0,
        "strategy": strategy,
    }
    if source_vertex is not None:
        repair["source_vertex"] = int(source_vertex)
    return selected, repair


def bone_slot(name):
    raw = name.encode("latin-1")
    if len(raw) >= 32:
        raise ValueError(f"bone name too long: {name!r}")
    return raw + b"\0" * (32 - len(raw))


def face_blob(template, verts, material, texptr):
    r = bytearray(template)
    struct.pack_into("<3H", r, 0, *verts)
    struct.pack_into("<H", r, 6, material)
    struct.pack_into("<I", r, F_TEX_PTR, texptr)
    return bytes(r)


def tex_blob(template, uvs, htex):
    r = bytearray(template)
    struct.pack_into("<3f", r, T_U, *(x[0] for x in uvs))
    struct.pack_into("<3f", r, T_V, *(x[1] for x in uvs))
    struct.pack_into("<I", r, T_HTEX, htex)
    struct.pack_into("<I", r, T_NEXT, 0)
    return bytes(r)


def blender_uvs_smd(uvs):
    if len(uvs) != 3:
        raise ValueError("SMD triangle requires exactly three UV corners")
    return [
        (float(u), 1.0 - float(v))
        for u, v in uvs
    ]


def material_templates(src_obj):
    base = src_obj["texbase"]
    by_mat = {}
    hsets = defaultdict(set)

    for f in src_obj["faces"]:
        delta = f["lp_tex"] - base
        if delta < 0 or delta % SZ_TEX:
            raise ValueError("source face has invalid TexLink pointer")
        ti = delta // SZ_TEX
        if not 0 <= ti < src_obj["nt"]:
            raise ValueError("source TexLink index out of range")
        tex = src_obj["texlinks"][ti]
        if tex["NextTex"] != 0:
            raise ValueError("V2 target source has multi-layer TexLink")
        mat = f["material"]
        hsets[mat].add(tex["hTexture"])
        by_mat.setdefault(mat, (f["raw"], tex["raw"]))

    for mat, hs in hsets.items():
        if len(hs) != 1:
            raise ValueError(
                f"material {mat}: multiple source hTexture values {sorted(hs)}"
            )
    return by_mat, {mat: next(iter(hs)) for mat, hs in hsets.items()}


def verify_output(data, target, nv, nf, object_index=None):
    infos = parse_file(data)
    o = parse_object(data, infos, target, object_index)

    if (o["nv"], o["nf"], o["nt"]) != (nv, nf, nf):
        raise ValueError("output counts mismatch")

    base = o["texbase"]
    for fi, f in enumerate(o["faces"]):
        if any(v >= nv for v in f["verts"]):
            raise ValueError(f"face {fi}: vertex OOB")
        d = f["lp_tex"] - base
        if d < 0 or d % SZ_TEX:
            raise ValueError(f"face {fi}: bad TexLink pointer")
        ti = d // SZ_TEX
        if not 0 <= ti < o["nt"]:
            raise ValueError(f"face {fi}: TexLink OOB")
        if o["texlinks"][ti]["NextTex"] != 0:
            raise ValueError(f"face {fi}: unexpected TexLink chain")

    if o["phys"]:
        if len(o["bones"]) != nv or any(not b for b in o["bones"]):
            raise ValueError("output Physique invalid")
    elif o["bones"]:
        raise ValueError("static output unexpectedly contains Physique bones")

    return infos, o



def sync_mesh_from_edit_mode(obj):
    """
    Commit the active Edit BMesh into the Mesh RNA datablock in memory.

    The .blend is not saved or modified on disk. Blender 5.x keeps live Edit
    Mode geometry/UV data in BMesh; the Mesh RNA UV array can legitimately
    report length 0 until Object Mode is entered.
    """
    original_mode = obj.mode
    synchronized = False

    if obj.mode == "EDIT":
        bpy.context.view_layer.objects.active = obj
        if not obj.select_get():
            obj.select_set(True)

        result = bpy.ops.object.mode_set(mode="OBJECT")
        if "FINISHED" not in result or obj.mode != "OBJECT":
            raise ValueError(
                f"failed to synchronize Edit Mode mesh: result={result}, "
                f"mode={obj.mode}"
            )
        synchronized = True

    obj.data.update()

    return {
        "original_mode": original_mode,
        "current_mode": obj.mode,
        "edit_mode_synchronized": synchronized,
    }


def require_uv_storage(mesh):
    if len(mesh.uv_layers) != 1:
        raise ValueError(
            f"requires exactly one UV layer; found {len(mesh.uv_layers)}"
        )

    uv = mesh.uv_layers.active
    if uv is None:
        raise ValueError("UV layer exists but no active UV layer is selected")

    loop_count = len(mesh.loops)
    uv_count = len(uv.data)

    if loop_count <= 0:
        raise ValueError(
            f"mesh has no corner loops: loops={loop_count}, "
            f"faces={len(mesh.polygons)}"
        )

    if uv_count != loop_count:
        raise ValueError(
            "UV storage is not synchronized/complete after Object Mode sync: "
            f"uv_layer={uv.name!r}, uv_data={uv_count}, "
            f"mesh_loops={loop_count}, faces={len(mesh.polygons)}"
        )

    return uv


def object_matrix_is_identity(obj, eps=1e-7):
    ident = Matrix.Identity(4)
    for r in range(4):
        for c in range(4):
            if abs(float(obj.matrix_world[r][c] - ident[r][c])) > eps:
                return False
    return True


def parse_args(argv):
    p = argparse.ArgumentParser()
    p.add_argument("--smd", required=True)
    p.add_argument("--skeleton", required=True)
    p.add_argument("--object", default=DEFAULT_TARGET)
    p.add_argument("--object-index", type=int)
    p.add_argument("--out", required=True)
    p.add_argument("--report")
    p.add_argument("--max-fit-error", type=float, default=0.02)
    p.add_argument("--expected-source-sha256")
    p.add_argument(
        "--physique-policy", choices=("auto", "strict", "source"), default="auto",
        help=(
            "auto (default) chooses one valid Blender bone deterministically and serializes it at weight 1.0, "
            "emitting repair warnings; strict refuses non-rigid weights; source preserves the serialized "
            "source-SMD Physique assignment by vertex index"
        ),
    )
    return p.parse_args(argv)


def main(argv):
    a = parse_args(argv)
    smd = Path(a.smd).expanduser().resolve()
    skel = Path(a.skeleton).expanduser().resolve()
    outp = Path(a.out).expanduser().resolve()

    target = a.object
    if not target:
        raise ValueError("--object must not be empty")

    src = smd.read_bytes()
    source_sha256 = sha(src)
    if a.expected_source_sha256 and source_sha256.lower() != a.expected_source_sha256.lower():
        raise ValueError(
            f"source SMD SHA256 mismatch: {source_sha256} != "
            f"{a.expected_source_sha256.lower()}"
        )

    infos = parse_file(src)
    so = parse_object(src, infos, target, a.object_index)
    target_index = int(so["info"]["index"])
    if not so["phys"]:
        raise ValueError(f"{target}: source object has no Physique")
    templates, htex_by_mat = material_templates(so)
    allowed_materials = set(templates)

    skeleton, skeleton_duplicate_conflicts = parse_skeleton(
        skel.read_bytes(), allow_conflicting_duplicates=True
    )
    conflict_keys = {str(x.get("name") or "").casefold() for x in skeleton_duplicate_conflicts}
    source_direct_conflicts = sorted({
        str(bone) for bone in (so.get("bones") or [])
        if str(bone).casefold() in conflict_keys
    })
    if source_direct_conflicts:
        raise ValueError(
            "conflicting duplicate skeleton node directly referenced by source Physique; "
            f"rigid first-match support is unsafe: {source_direct_conflicts}"
        )

    if a.object_index is not None:
        blender_hits = [
            candidate for candidate in bpy.data.objects
            if candidate.type == "MESH"
            and int(candidate.get("pt_smd_object_index", -1)) == target_index
        ]
        if len(blender_hits) != 1:
            raise ValueError(
                f"{target}: Blender mesh for object_index={target_index} "
                f"expected exactly 1, found {len(blender_hits)}"
            )
        obj = blender_hits[0]
        logical = str(obj.get("pt_smd_node_name") or obj.name)
        if logical != target:
            raise ValueError(
                f"object_index={target_index}: Blender logical NodeName "
                f"{logical!r} != source {target!r}"
            )
    else:
        logical_hits = [
            candidate for candidate in bpy.data.objects
            if candidate.type == "MESH"
            and str(candidate.get("pt_smd_node_name") or candidate.name) == target
        ]
        if len(logical_hits) != 1:
            raise ValueError(
                f"{target}: Blender mesh ambiguous/missing; "
                f"logical_matches={len(logical_hits)}; use --object-index for duplicates"
            )
        obj = logical_hits[0]

    mode_sync = sync_mesh_from_edit_mode(obj)

    mesh = obj.data
    mesh.update()
    nv = len(mesh.vertices)
    source_polygons = len(mesh.polygons)

    if not 3 <= nv <= MAX_VERTICES:
        raise ValueError(f"vertex count {nv} outside safe range 3..{MAX_VERTICES}")
    if source_polygons < 1:
        raise ValueError("mesh has no polygons")
    if nv > 65535:
        raise ValueError("vertex count exceeds uint16 face-index format")

    uv = require_uv_storage(mesh)
    export_triangles, triangulation_info = build_export_triangles(mesh)
    nf = len(export_triangles)

    if not 1 <= nf <= MAX_FACES:
        raise ValueError(
            f"triangulated export face count {nf} outside safe range "
            f"1..{MAX_FACES}"
        )

    if not object_matrix_is_identity(obj):
        raise ValueError(
            f"{target} object transform is not identity; apply transforms "
            "(Ctrl+A) before export"
        )

    for fi, tri in enumerate(export_triangles):
        mat = tri["material_index"]
        if mat not in allowed_materials:
            raise ValueError(
                f"export triangle {fi} / polygon {tri['polygon_index']}: "
                f"material {mat} absent from source object {target}; "
                f"allowed={sorted(allowed_materials)}"
            )

    if a.physique_policy == "source" and nv != int(so["nv"]):
        raise ValueError(
            "--physique-policy source requires source-compatible vertex indexing: "
            f"source_vertices={so['nv']} blender_vertices={nv}"
        )

    bones = []
    physique_workspace_mismatches = []
    physique_auto_repairs = []
    source_bones = list(so.get("bones") or [])
    source_position_map = _source_physique_position_map(so, skeleton)
    repair_seed = f"{source_sha256}|{target}|{target_index}"
    for vi in range(nv):
        rows = rigid_bone_rows(obj, vi)
        if a.physique_policy == "source":
            if vi >= len(source_bones) or not source_bones[vi]:
                raise ValueError(f"vertex {vi}: source Physique assignment missing")
            bone = str(source_bones[vi])
            strict_match = (
                len(rows) == 1
                and rows[0][0] == bone
                and abs(rows[0][1] - 1.0) <= 1e-5
            )
            if not strict_match:
                physique_workspace_mismatches.append({
                    "vertex": vi,
                    "source_bone": bone,
                    "blender_weights": [[name, weight] for name, weight in rows],
                })
        elif a.physique_policy == "auto":
            source_bone, source_strategy, source_vertex = _source_bone_for_blender_vertex(
                obj, vi, src_obj=so, skeleton=skeleton, position_map=source_position_map,
            )
            bone, repair = auto_rigid_bone(
                obj, vi, seed_material=repair_seed, skeleton=skeleton,
                conflict_keys=conflict_keys, source_bone=source_bone,
                source_strategy=source_strategy, source_vertex=source_vertex,
            )
            if repair is not None:
                physique_auto_repairs.append(repair)
        else:
            bone = rigid_bone(obj, vi)
        if bone.casefold() in conflict_keys:
            raise ValueError(
                f"vertex {vi}: bone {bone!r} references a conflicting duplicate skeleton node; "
                "rigid first-match support is unsafe"
            )
        if bone not in skeleton:
            raise ValueError(f"vertex {vi}: bone {bone!r} missing from skeleton")
        bones.append(bone)

    # Geometry-derived equal-weight normals, proven for newly-created topology.
    eqn, normal_topology = equal_normals(mesh, export_triangles, src_obj=so, skeleton=skeleton, bones=bones)

    mags_by_bone = defaultdict(list)
    all_mags = []
    for vi, sv in enumerate(so["vertices"]):
        nx, ny, nz = sv[3:6]
        mag = math.sqrt(nx * nx + ny * ny + nz * nz)
        if mag > 0:
            mags_by_bone[so["bones"][vi]].append(mag)
            all_mags.append(mag)
    if not all_mags:
        raise ValueError("source normal calibration is empty")
    fallback_mag = statistics.median(all_mags)

    vertices = bytearray()
    physique = bytearray()
    fit_errors = []
    normal_scales = []
    vertex_rows = []
    # PT_RC6_11_RIGID_FIT_PRECOMPUTE: each bone inverse/coefficients are
    # invariant across all vertices bound to that bone.
    fit_prepared = {bone: prepare_fit_local(skeleton[bone]) for bone in set(bones)}
    preserved_zero_unreferenced = set(normal_topology.get("source_zero_normal_unreferenced_vertices") or [])

    for vi in range(nv):
        bone = bones[vi]
        tm = skeleton[bone]
        prepared = fit_prepared[bone]
        world = tuple(float(x) for x in mesh.vertices[vi].co)

        local, represented, fit = fit_local_prepared(world, prepared)
        if fit > a.max_fit_error:
            raise ValueError(
                f"vertex {vi}: bind-position fit {fit} exceeds "
                f"--max-fit-error {a.max_fit_error}"
            )

        if vi in preserved_zero_unreferenced:
            # Exact preservation for a source/export-unreferenced vertex only.
            # The zero normal is shipped data and cannot influence any face.
            normal = tuple(int(x) for x in so["vertices"][vi][3:6])
            scale = 0.0
        else:
            local_dir = normalize(_apply_inverse_row3(eqn[vi], prepared["inv"]))
            scale = (
                statistics.median(mags_by_bone[bone])
                if mags_by_bone.get(bone)
                else fallback_mag
            )
            normal = tuple(int(round(x * scale)) for x in local_dir)

        vertices.extend(struct.pack("<6i", *local, *normal))
        physique.extend(bone_slot(bone))
        fit_errors.append(fit)
        normal_scales.append(scale)

        vertex_rows.append(dict(
            index=vi,
            bone=bone,
            world=list(world),
            local_fixed=list(local),
            represented_world=list(represented),
            fit_error=fit,
            normal_local=list(normal),
            normal_scale=scale,
        ))

    faces = bytearray()
    tex = bytearray()

    for fi, tri in enumerate(export_triangles):
        ids = tri["vertices"]
        if any(v < 0 or v >= nv for v in ids):
            raise ValueError(f"export triangle {fi}: invalid vertex index")
        if any(v > 65535 for v in ids):
            raise ValueError("uint16 face-index overflow")

        mat = tri["material_index"]
        face_template, tex_template = templates[mat]

        ptr = so["texbase"] + fi * SZ_TEX
        if ptr > 0xFFFFFFFF:
            raise ValueError("historical TexLink pointer overflow")

        faces.extend(face_blob(face_template, ids, mat, ptr))
        tex.extend(
            tex_blob(
                tex_template,
                blender_uvs_smd(tri["uvs"]),
                htex_by_mat[mat],
            )
        )

    nt = nf

    raw = bytearray(so["raw"])
    for off, val in (
        (O_VERTEX_CAP, nv),
        (O_FACE_CAP, nf),
        (O_NV, nv),
        (O_NF, nf),
        (O_NT, nt),
    ):
        struct.pack_into("<i", raw, off, val)

    motion_payload = object_local_blob(src, so)
    block = (
        bytes(raw)
        + bytes(vertices)
        + bytes(faces)
        + bytes(tex)
        + motion_payload
        + bytes(physique)
    )

    expected_size = (
        SZ_OBJ
        + nv * SZ_VERT
        + nf * SZ_FACE
        + nt * SZ_TEX
        + so["nr"] * SZ_ROT
        + so["np"] * SZ_POS
        + so["ns"] * SZ_SCALE
        + so["nr"] * SZ_MATRIX
        + nv * 32
    )
    if len(block) != expected_size:
        raise ValueError(
            f"new {target} block size {len(block)} != expected {expected_size}"
        )

    prefix = bytearray(src[:infos[0]["start"]])
    blocks = []
    cursor = infos[0]["start"]
    table = []

    for inf in infos:
        if int(inf["index"]) == target_index:
            b = block
        else:
            b = src[inf["start"]:inf["start"] + inf["length"]]

        blocks.append(b)
        struct.pack_into("<i", prefix, inf["table_off"] + 32, len(b))
        struct.pack_into("<i", prefix, inf["table_off"] + 36, cursor)
        table.append(dict(
            name=inf["name"],
            old_start=inf["start"],
            new_start=cursor,
            old_length=inf["length"],
            new_length=len(b),
        ))
        cursor += len(b)

    source_object_end = infos[-1]["start"] + infos[-1]["length"]
    opaque_suffix = src[source_object_end:]
    out = bytes(prefix) + b"".join(blocks) + opaque_suffix

    out_infos, out_obj = verify_output(out, target, nv, nf, target_index)
    output_motion_payload = object_local_blob(out, out_obj)
    if output_motion_payload != motion_payload:
        raise ValueError("object-local animation payload changed during geometry rebuild")

    unrelated_ok = 0
    for old, new in zip(infos, out_infos):
        if int(old["index"]) == target_index:
            continue
        old_block = src[old["start"]:old["start"] + old["length"]]
        new_block = out[new["start"]:new["start"] + new["length"]]
        if old_block != new_block:
            raise ValueError(f"unrelated object changed: {old['name']}")
        unrelated_ok += 1

    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_bytes(out)

    report = dict(
        tool="PT_SMD_MODEL_062_FREE_MESH_WRITER_V3",
        blend=bpy.data.filepath,
        object=target,
        object_index=target_index,
        blender_object=obj.name,
        mode_sync=mode_sync,
        source_smd=str(smd),
        source_sha256=sha(src),
        output=str(outp),
        output_sha256=sha(out),
        source_counts=dict(
            vertices=so["nv"], faces=so["nf"], texlinks=so["nt"]
        ),
        artist_mesh=dict(
            vertices=nv,
            source_polygons=source_polygons,
            export_triangles=nf,
            triangulation_delta=nf-source_polygons,
            triangulation=triangulation_info,
        ),
        output_counts=dict(vertices=nv, faces=nf, texlinks=nt),
        vertex_delta=nv - so["nv"],
        face_delta=nf - so["nf"],
        artist_mesh_triangulated_in_memory=True,
        artist_mesh_saved_topology_unchanged=True,
        all_vertices_rebuilt=True,
        all_faces_rebuilt=True,
        all_texlinks_rebuilt=True,
        legacy_degenerate_topology=normal_topology,
        all_physique_rebuilt=True,
        physique_policy=a.physique_policy,
        source_physique_preserved=(a.physique_policy == "source"),
        blender_weight_edits_authorized=(a.physique_policy == "auto"),
        auto_rigid_weight_repair_enabled=(a.physique_policy == "auto"),
        blender_weight_mismatch_count=len(physique_workspace_mismatches),
        blender_weight_mismatches=physique_workspace_mismatches[:64],
        blender_weight_mismatches_truncated=max(0, len(physique_workspace_mismatches) - 64),
        blender_weight_repair_count=len(physique_auto_repairs),
        blender_weight_repairs=physique_auto_repairs[:64],
        blender_weight_repairs_truncated=max(0, len(physique_auto_repairs) - 64),
        object_local_animation_counts={"rot": so["nr"], "pos": so["np"], "scale": so["ns"]},
        object_local_animation_payload_bytes=len(motion_payload),
        object_local_animation_preserved_byte_identical=(output_motion_payload == motion_payload),
        max_vertex_fit_error=max(fit_errors) if fit_errors else 0.0,
        mean_vertex_fit_error=(
            sum(fit_errors) / len(fit_errors) if fit_errors else 0.0
        ),
        allowed_materials=sorted(allowed_materials),
        hTexture_by_material={str(k): v for k, v in htex_by_mat.items()},
        unique_rigid_bones=sorted(set(bones)),
        rigid_bone_count=len(set(bones)),
        skeleton_duplicate_conflict_count=len(skeleton_duplicate_conflicts),
        skeleton_duplicate_conflicts=skeleton_duplicate_conflicts,
        duplicate_conflict_direct_physique_refs=source_direct_conflicts,
        animation_pose_certified_from_duplicate_policy=False if skeleton_duplicate_conflicts else None,
        unrelated_object_blocks_byte_identical=unrelated_ok,
        opaque_trailing_bytes_preserved=len(opaque_suffix),
        opaque_trailing_bytes_byte_identical=(out[-len(opaque_suffix):] == opaque_suffix) if opaque_suffix else True,
        input_size=len(src),
        output_size=len(out),
        growth_bytes=len(out) - len(src),
        object_table=table,
        vertex_rows=vertex_rows,
        semantic_check="PASS",
        free_mesh_writer_check="PASS",
    )

    rp = (
        Path(a.report).expanduser().resolve()
        if a.report
        else outp.with_suffix(".json")
    )
    rp.parent.mkdir(parents=True, exist_ok=True)
    rp.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("PT_SMD_MODEL_062_FREE_MESH_WRITER_V3")
    print(f"object={target}")
    print(f"object_index={target_index}")
    print(f"blender_object={obj.name}")
    print(f"source_sha256={source_sha256}")
    print(f"original_object_mode={mode_sync['original_mode']}")
    print(f"current_object_mode={mode_sync['current_mode']}")
    print(f"edit_mode_synchronized={mode_sync['edit_mode_synchronized']}")
    print(f"source_counts={so['nv']}/{so['nf']}/{so['nt']}")
    print(f"artist_vertices={nv}")
    print(f"artist_source_polygons={source_polygons}")
    print(f"export_triangles={nf}")
    print(f"triangulation_delta={nf-source_polygons:+d}")
    print("triangulation_method=TEMP_BMESH_BEAUTY")
    print("artist_mesh_modified=False")
    print(f"output_counts={nv}/{nf}/{nt}")
    print(f"vertex_delta={nv-so['nv']:+d}")
    print(f"face_delta={nf-so['nf']:+d}")
    print("artist_mesh_triangulated_in_memory=True")
    print("artist_mesh_saved_topology_unchanged=True")
    print("all_vertices_rebuilt=True")
    print("all_faces_rebuilt=True")
    print("all_texlinks_rebuilt=True")
    print("all_physique_rebuilt=True")
    print(f"physique_policy={a.physique_policy}")
    print(f"blender_weight_mismatch_count={len(physique_workspace_mismatches)}")
    print(f"blender_weight_repair_count={len(physique_auto_repairs)}")
    for repair in physique_auto_repairs[:16]:
        print(
            "WARNING AUTO_RIGID_WEIGHT_REPAIR "
            f"vertex={repair['vertex']} selected={repair['selected_bone']!r} "
            f"original={repair['original_weights']!r} serialized_weight=1.0 "
            f"strategy={repair['strategy']}"
        )
    if len(physique_auto_repairs) > 16:
        print(f"WARNING AUTO_RIGID_WEIGHT_REPAIR additional={len(physique_auto_repairs)-16}")
    print(f"rigid_bone_count={len(set(bones))}")
    print(f"unique_rigid_bones={sorted(set(bones))}")
    print(f"allowed_materials={sorted(allowed_materials)}")
    print(
        f"max_vertex_fit_error="
        f"{(max(fit_errors) if fit_errors else 0.0):.12g}"
    )
    print(
        f"mean_vertex_fit_error="
        f"{(sum(fit_errors)/len(fit_errors) if fit_errors else 0.0):.12g}"
    )
    print(f"unrelated_object_blocks_byte_identical={unrelated_ok}")
    print(f"input_size={len(src)}")
    print(f"output_size={len(out)}")
    print(f"growth_bytes={len(out)-len(src):+d}")
    print(f"input_sha256={sha(src)}")
    print(f"output_sha256={sha(out)}")
    print(f"report={rp}")
    print("semantic_check=PASS")
    print("free_mesh_writer_check=PASS")


if __name__ == "__main__":
    try:
        argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
        main(argv)
    except Exception as exc:
        print(f"free_mesh_writer_check=FAIL: {type(exc).__name__}: {exc}")
        raise
