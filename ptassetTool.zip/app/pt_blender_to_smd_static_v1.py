#!/usr/bin/env python3
"""
Static/no-Physique SMD Model0.62 writer V1.

Strict scope:
- source target has no Physique;
- existing object-local animation arrays are preserved byte-identical;
- one TexLink layer per face;
- existing material IDs only.

It writes a NEW SMD only. It never writes the client.
"""
from __future__ import annotations
import argparse, importlib.util, json, math, pathlib, statistics, struct, sys

def load_core():
    p = pathlib.Path(__file__).resolve().with_name(
        "pt_blender_to_smd_free_mesh_v3.py"
    )
    if not p.is_file():
        raise FileNotFoundError(p)
    spec = importlib.util.spec_from_file_location("pt_static_writer_core", p)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod

def parse_args(argv):
    p = argparse.ArgumentParser()
    p.add_argument("--smd", required=True)
    p.add_argument("--object", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--report")
    p.add_argument("--expected-source-sha256")
    return p.parse_args(argv)

def main(argv):
    a = parse_args(argv)
    core = load_core()
    srcp = pathlib.Path(a.smd).expanduser().resolve()
    outp = pathlib.Path(a.out).expanduser().resolve()
    src = srcp.read_bytes()
    source_sha = core.sha(src)

    if a.expected_source_sha256 and source_sha != a.expected_source_sha256.lower():
        raise ValueError("source SHA mismatch")

    infos = core.parse_file(src)
    so = core.parse_object(src, infos, a.object)
    if so["phys"]:
        raise ValueError(f"{a.object}: source has Physique; use rigid writer")
    templates, htex_by_mat = core.material_templates(so)
    allowed_materials = set(templates)

    obj = core.bpy.data.objects.get(a.object)
    if obj is None or obj.type != "MESH":
        raise ValueError(f"{a.object}: Blender mesh missing")
    core.sync_mesh_from_edit_mode(obj)
    mesh = obj.data
    mesh.update()

    nv = len(mesh.vertices)
    if not 3 <= nv <= core.MAX_VERTICES:
        raise ValueError(f"vertex count {nv} outside safe range")
    if nv > 65535:
        raise ValueError("uint16 vertex-index overflow")
    if not core.object_matrix_is_identity(obj):
        raise ValueError("object transform is not identity")

    core.require_uv_storage(mesh)
    triangles, tri_info = core.build_export_triangles(mesh)
    nf = len(triangles)
    if not 1 <= nf <= core.MAX_FACES:
        raise ValueError(f"face count {nf} outside safe range")

    for fi, tri in enumerate(triangles):
        if tri["material_index"] not in allowed_materials:
            raise ValueError(
                f"triangle {fi}: material {tri['material_index']} absent "
                f"from source {sorted(allowed_materials)}"
            )

    # PT_RC6_6_EQUAL_NORMALS_API_UNPACK
    # equal_normals() returns (per_vertex_normals, topology_diagnostics).
    # The previous static writer treated the 2-tuple itself as the normal array.
    eqn, normal_topology = core.equal_normals(mesh, triangles)
    if len(eqn) != nv:
        raise ValueError(
            f"equal_normals vertex-count mismatch: normals={len(eqn)} vertices={nv}"
        )
    mags = [
        math.sqrt(v[3] * v[3] + v[4] * v[4] + v[5] * v[5])
        for v in so["vertices"]
        if v[3] or v[4] or v[5]
    ]
    if not mags:
        raise ValueError("source normal calibration is empty")
    normal_scale = statistics.median(mags)

    vertices = bytearray()
    for vi, vertex in enumerate(mesh.vertices):
        xyz = tuple(int(round(float(c) * 256.0)) for c in vertex.co)
        nd = core.normalize(eqn[vi])
        normal = tuple(int(round(x * normal_scale)) for x in nd)
        vertices.extend(struct.pack("<6i", *xyz, *normal))

    faces = bytearray()
    texlinks = bytearray()
    for fi, tri in enumerate(triangles):
        ids = tri["vertices"]
        if any(v < 0 or v >= nv or v > 65535 for v in ids):
            raise ValueError(f"triangle {fi}: invalid vertex index")
        mat = tri["material_index"]
        face_template, tex_template = templates[mat]
        ptr = so["texbase"] + fi * core.SZ_TEX
        faces.extend(core.face_blob(face_template, ids, mat, ptr))
        texlinks.extend(
            core.tex_blob(
                tex_template,
                core.blender_uvs_smd(tri["uvs"]),
                htex_by_mat[mat],
            )
        )

    raw = bytearray(so["raw"])
    for off, val in (
        (core.O_VERTEX_CAP, nv),
        (core.O_FACE_CAP, nf),
        (core.O_NV, nv),
        (core.O_NF, nf),
        (core.O_NT, nf),
    ):
        struct.pack_into("<i", raw, off, val)

    motion_payload = core.object_local_blob(src, so)
    block = bytes(raw) + bytes(vertices) + bytes(faces) + bytes(texlinks) + motion_payload
    expected = (
        core.SZ_OBJ
        + nv * core.SZ_VERT
        + nf * core.SZ_FACE
        + nf * core.SZ_TEX
        + so["nr"] * core.SZ_ROT
        + so["np"] * core.SZ_POS
        + so["ns"] * core.SZ_SCALE
        + so["nr"] * core.SZ_MATRIX
    )
    if len(block) != expected:
        raise ValueError("rebuilt static block size mismatch")

    prefix = bytearray(src[: infos[0]["start"]])
    blocks = []
    cursor = infos[0]["start"]
    non_target_identical = 0

    for inf in infos:
        bb = (
            block
            if inf["name"] == a.object
            else src[inf["start"] : inf["start"] + inf["length"]]
        )
        struct.pack_into("<i", prefix, inf["table_off"] + 32, len(bb))
        struct.pack_into("<i", prefix, inf["table_off"] + 36, cursor)
        blocks.append(bb)
        cursor += len(bb)
        if inf["name"] != a.object:
            non_target_identical += 1

    out = bytes(prefix) + b"".join(blocks)
    _out_infos, out_obj = core.verify_output(out, a.object, nv, nf)
    output_motion_payload = core.object_local_blob(out, out_obj)
    if output_motion_payload != motion_payload:
        raise ValueError("object-local animation payload changed during static geometry rebuild")

    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_bytes(out)

    result = {
        "tool": "PT_SMD_STATIC_WRITER_V1",
        "source_smd": str(srcp),
        "source_sha256": source_sha,
        "object": a.object,
        "source_counts": {
            "vertices": so["nv"], "faces": so["nf"], "texlinks": so["nt"]
        },
        "artist_mesh": {
            "vertices": nv,
            "source_polygons": len(mesh.polygons),
            "export_triangles": nf,
            "triangulation": tri_info,
            "normal_topology": normal_topology,
        },
        "output_counts": {"vertices": nv, "faces": nf, "texlinks": nf},
        "physique": False,
        "object_local_animation_counts": {"rot": so["nr"], "pos": so["np"], "scale": so["ns"]},
        "object_local_animation_payload_bytes": len(motion_payload),
        "object_local_animation_preserved_byte_identical": (output_motion_payload == motion_payload),
        "non_target_object_blocks_byte_identical": non_target_identical,
        "output": str(outp),
        "output_sha256": core.sha(out),
        "client_modified": False,
        "static_writer_check": "PASS",
    }
    rp = (
        pathlib.Path(a.report).expanduser().resolve()
        if a.report else outp.with_suffix(".json")
    )
    rp.parent.mkdir(parents=True, exist_ok=True)
    rp.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    print("PT_SMD_STATIC_WRITER_V1")
    print(f"object={a.object}")
    print(f"output_counts={nv}/{nf}/{nf}")
    print("physique=False")
    print(f"non_target_object_blocks_byte_identical={non_target_identical}")
    print(f"output={outp}")
    print(f"output_sha256={core.sha(out)}")
    print("client_modified=False")
    print("static_writer_check=PASS")

if __name__ == "__main__":
    try:
        argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
        main(argv)
    except Exception as exc:
        print(f"static_writer_check=FAIL: {type(exc).__name__}: {exc}")
        raise
