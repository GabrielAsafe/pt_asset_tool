# Etervale + PT Asset Tool — Dossiê de integração

**Data da consolidação:** 2026-11-09  
**Objetivo:** reunir **todos os três patches incrementais produzidos nesta integração**, os respectivos **três scripts de aplicação**, os achados, evidências, documentação e o relatório de assets ausentes.

## Conteúdo

- `patches/`: patches ZIP originais e instaladores Python; preservar seus nomes e aplicar **na ordem 1 → 2 → 3**, se uma futura instalação exigir.
- `relatorios/`: análise horizontal/vertical original, achados consolidados, validações e relatório de **assets em falta** em Markdown/JSON/CSV.
- `documentacao/`: documentação técnica extraída dos próprios patches, incluindo formatos legados, ponte unificada e diagnósticos de textura.
- `proveniencia/`: manifests de migração e dos patches.
- `evidencias/`: logs/árvore fornecidos anteriormente, teste inicial e censo textual C# de snapshot; arquivos de histórico não substituem os relatórios da máquina local.
- `GUIA_APLICACAO_E_VALIDACAO.md`: comandos seguros de instalação e validação.
- `SHA256SUMS.txt` + `verificar_integridade.py`: checagem de integridade de tudo que está no dossiê.

## Resultado atualmente certificado

A instalação e a configuração da raiz única funcionaram; a UI indexou 39.956 arquivos; o `AssetDump` C# aceitou o mapa real; o exportador GLB funcionou, mas com uma textura ausente. A textura **`tem_wall04.bmp` está ausente nas localizações pesquisadas**, e foi confirmada em **1 face no material 173** de `Field/Ricarten/village-2.smd`. O status de textura estrita permaneceu `FAILED_TEXTURE_FALLBACKS`. Não existe evidência de carregamento GLB nativo no jogo, nem de certificação completa dos writers.

Consulte `relatorios/ASSETS_EM_FALTA_2026-11-09.md` antes de modificar assets. Esse arquivo **não é um censo completo**. Para os detalhes das ferramentas e dos limites de prova, consulte `relatorios/ACHADOS_CONSOLIDADOS_2026-11-09.md`.

**Este ZIP é um pacote de arquivo/recuperação, não o aplicativo completo.** Não substitui `assetTool.zip`, o repositório `Etervale-git` nem os backups reais guardados nos diretórios `patches/_backups` da máquina do usuário.
