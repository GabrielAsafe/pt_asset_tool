# Relatório de assets ausentes — Etervale

**Data:** 9 de novembro de 2026  
**Base da auditoria:** logs fornecidos pelo usuário, com comandos executados em seu computador.  
**Escopo:** *ocorrências comprovadas até o momento*, não inventário completo de todos os arquivos ausentes do jogo.

## Resumo

- **1 asset físico ausente confirmado nas buscas realizadas:** `tem_wall04.bmp`.
- **1 referência geométrica confirmada:** material 173 do mapa `assets/Field/Ricarten/village-2.smd`, com **1 face** associada.
- **1 fallback de textura na exportação GLB:** `tem_wall04.bmp` — `file not found`.
- **Certificação estrita:** `FAILED_TEXTURE_FALLBACKS` (comportamento esperado).
- **Outros assets ausentes:** não apurados; não considerar esta relação como inventário total.

## Ocorrência ASSET-MISS-001 — tem_wall04.bmp

| Campo | Evidência ou conclusão |
|---|---|
| Arquivo esperado | `assets/Field/Ricarten/tem_wall04.bmp` (nome referenciado pelo SMD) |
| Origem da referência | `assets/Field/Ricarten/village-2.smd` |
| Índice do material | `173` |
| Blend | `ALPHA` |
| Número de faces | `1` (confirmado por `AssetDump --matbounds`) |
| Geometria | Origem aproximada `(-236,5; 304,1; 18361,2)`, extensão `(71,9; 107,0; 1,0)` no formato mostrado pelo utilitário; unidades/eixos não foram certificados |
| Diagnóstico do exportador | `texture fallback: 'tem_wall04.bmp' (file not found)` |
| Busca em `assets` | Sem correspondência exata (case insensitive) |
| Busca em `~/Transferências` | Sem correspondência exata |
| Busca em `~/armazem/priston` | Sem correspondência exata |
| Histórico de nomes do Git | `git log --all --name-only ... | grep -i tem_wall04` não retornou caminho |
| Resultado da validação | `FAILED_TEXTURE_FALLBACKS` com `--strict-textures`; GLB gerado não é certificação visual |
| Integridade da source | `source_unchanged: true` |
| Solução aplicada | Nenhuma; ainda falta o arquivo original |

### Evidências técnicas

`PristonTale.AssetDump --materials`:

```text
171  ALPHA ... tem_wall02.BMP
172  ALPHA ... tem_wall03.BMP
173  ALPHA ... tem_wall04.bmp
174  ALPHA ... arch_bg.BMP
175  ALPHA ... tem_wall05.BMP
```

`PristonTale.AssetDump --matbounds`:

```text
173  ALPHA           1  (-236,5, 304,1, 18361,2)       (71,9, 107,0, 1,0)              tem_wall04.bmp
```

`GltfExport`:

```text
stage: 41783 verts, 44226 faces, 262 textures (1 missing or invalid)
texture fallback: 'tem_wall04.bmp' (file not found)
```

`--strict-textures` terminou com `status: FAILED_TEXTURE_FALLBACKS` apesar do processo C# ter `exit_code: 0`; a saída é intencionalmente reprovada no nível de certificação, não no nível de geração.

### Não confundir com outros arquivos

Foram encontrados `lost_temple_wall04.bmp`, `de-wall04.bmp` e variantes. **Não são evidências de equivalência** com `tem_wall04.bmp`, nem devem ser renomeados automaticamente.

### Ação recomendada

Manter o mapa e o material intactos, registrar a falha de dependência no catálogo e recuperar o arquivo com proveniência verificável (inclusive pesquisando dentro de arquivos compactados ou fontes externas autorizadas, que não foram exaustivamente examinados). Se a textura original não for recuperável, uma substituição artística deve ser uma decisão explícita, registrada como reconstrução, não recuperação.

## Lacunas da auditoria

Não foi executado um censo completo de referências físicas de todo o catálogo. A UI indexou **39.956 arquivos**, mas esse total não demonstra cobertura de dependências. A inspeção de um único SMD não permite afirmar que o restante do jogo está completo. Também não foram encontrados candidatos `.smd/.smb/.inx` em `app/pt_build` no `find` apresentado; isso **não significa assets ausentes do jogo**, mas **ausência de candidatos de writer para a certificação planejada**.

Os relatórios JSON/CSV na mesma pasta descrevem somente a ocorrência confirmada acima.
