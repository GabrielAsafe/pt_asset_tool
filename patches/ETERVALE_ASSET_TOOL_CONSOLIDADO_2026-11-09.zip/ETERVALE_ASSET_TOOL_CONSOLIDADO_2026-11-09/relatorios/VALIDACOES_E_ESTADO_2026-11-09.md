# Histórico de validações e respectivos níveis de prova

| Teste | Observado | Nível de evidência |
|---|---|---|
| Baseline de testes selecionados | 166 aprovados / 1 falha de fixture | Python, análise inicial |
| `data-types` | 10 testes aprovados | Execução local via terminal |
| Ponte da raiz única | 14 testes aprovados | Execução local via terminal |
| Diagnóstico de textura e GLB | 19 testes aprovados | Execução local via terminal |
| Recompilação de packs Summit | 10 packs em igualdade byte a byte no ensaio | Legacy-only; não demonstra carregamento no C# |
| Configuração da raiz única | PASS, resolved_client_root=`.../assets`, resolved_server_root=`.../assets/GameServer` | Configuração local |
| Auditoria C# | PASS, 1094 `.cs` no checkout | Censo textual apenas |
| `AssetDump` build + leitura | Build sem warnings/erros, saída `READER_ACCEPTED` para village-2.smd | Leitor C# real, não prova visual |
| `GltfExport` build + export | Build sem warnings/erros, GLB exportado | Exportação com falha de textura |
| `inspect-glb` | GLB_VALID_STRUCTURAL_ONLY, errors=[] | Estrutura; não runtime |
| `export-glb --strict-textures` | FAILED_TEXTURE_FALLBACKS | Verificação de cobertura (1 ausência) |
| Listagem de candidatos `.smd/.smb/.inx` em staging | Zero paths devolvidos | Writers pendentes de teste nativo |
| UI web | READY, catálogo de 39956 arquivos | Servidor de UI iniciado, não certificação de workflows |

## Evidências numéricas do arquivo Ricarten

Modelo origem: `assets/Field/Ricarten/village-2.smd`  
SHA-256 da origem: `44a58c6ea44c5537120e2ba6b4d67df47f798faacf31f7d0922fd481825f06aa`  
SHA-256 do GLB exportado: `6b80eb8f65b9f35608cbc98c306e4344661455e4805a0f49fba0ed5b133bf3ab`  
342 materiais, 41783 vértices, 44226 faces, 45941 texLinks, 79 luzes, 319 faces de colisão.  
GLB reportado: 1 cena, 2 nodes, 2 meshes, 263 materiais, 262 imagens, 263 texturas, 263 samplers, 0 animações, 0 skins, 1315 accessors, 264 bufferViews, 1 buffer, 0 erros.  
**Uma textura faltante**: `tem_wall04.bmp`.

## Limitações

Os relatórios nativos foram reproduzidos neste documento com base nas saídas enviadas na conversa; **não são arquivos de `pt_build` copiados da máquina do usuário**. Para preservação forense integral dos relatórios JSON, exporte a pasta `app/pt_build/etervale/exports`, `validation` e as saídas necessárias diretamente de sua instalação local. Não inclua backups/certificados por acidente.
