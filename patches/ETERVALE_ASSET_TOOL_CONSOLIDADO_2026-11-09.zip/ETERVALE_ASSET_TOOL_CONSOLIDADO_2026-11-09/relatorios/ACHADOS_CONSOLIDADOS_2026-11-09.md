# Achados consolidados — PT Asset Tool / Etervale

**Consolidação realizada em 2026-11-09.** Os achados iniciais vêm da revisão dos anexos e de testes isolados; os resultados mais recentes abaixo vêm dos logs de execução no computador do usuário. Os estados não devem ser confundidos com certificação visual no runtime.

## Objetivo e arquitetura

O Etervale migrou para uma raiz única: `/home/gabriel/Transferências/Etervale-git`. O Asset Tool fica em `/home/gabriel/Transferências/pt_asset_tool`. A configuração nova usa apenas `game_root`, descobrindo:

- `assets/` (catálogo físico), `assets/GameServer/` (dados legados de servidor);
- `Client/`, `Server/`, `Shared/`, `Persistence/` (código C#);
- `tools/`, `scripts/` e `3d_glb/blender` (toolchain e workspace).

Ferramentas C# que dependem das bibliotecas do jogo, como `PristonTale.AssetDump` e `PristonTale.GltfExport`, permanecem no repositório Etervale; a ponte do Asset Tool pode invocá-las sem duplicar seus assemblies. Os geradores antigos de packs Summit são preservados como ferramentas de dados; não se presume que `SMAP/SCFG/SRES/SFLD/...` sejam consumidos pelo runtime C# novo.

## Três patches e o que entregaram

| Ordem | Patch | Principal conteúdo | Testes informados |
|---|---|---|---|
| 1 | `assetTool_Etervale_data_types_patch.zip` | 109 ferramentas de formatos/ASE preservadas, CLI `data-types`, schemas e documentação | `10 passed` na máquina do usuário; compilações legacy byte a byte no ambiente de análise |
| 2 | `assetTool_Etervale_unified_integration_patch.zip` | Configuração de raiz única, auditoria textual C#, AssetDump, exportação GLB, validação em lote | `14 passed` na máquina do usuário |
| 3 | `assetTool_Etervale_texture_diagnostics_patch.zip` | Trace de textura, `--strict-textures`, `inspect-glb` estrutural | `19 passed` na máquina do usuário |

Os três patches **já foram aplicados** com backup no computador do usuário, conforme saída de terminal; o ZIP deste dossiê é um arquivo de referência e recuperação, não uma instrução para substituir sua instalação atual.

## Resultados nativos confirmados

- A aplicação web iniciou com `PT_ASSET_UI_SERVER_V1`, `status: READY`, `ui_version: 1.0.5`, backend `1.0.0`, **39.956 arquivos** indexados, servidor em `http://127.0.0.1:44743/`. Não houve modificação do cliente ou do core segundo o log da UI.
- `config show` reportou `ETERVALE_UNIFIED_V1` e `status: PASS`. `etervale status` reportou `READY_TO_VALIDATE`, não certificação funcional global.
- Auditoria textual C# no checkout local: **1.094 arquivos** (Client 424, Server 40, Shared 502, Persistence 77, tools 51). Contagens de literals incluem comentários/testes; **não são grafo semântico de dependências**. Existe um JSON anterior de snapshot com contagem possivelmente diferente; é preservado como evidência histórica, não reescrito.
- `dotnet build` de `PristonTale.AssetDump` passou com 0 warnings e 0 errors. O SMD `Field/Ricarten/village-2.smd` foi aceito (`READER_ACCEPTED`) com 342 materiais, 41.783 vértices, 44.226 faces, 45.941 texLinks e 319 faces de colisão reportadas.
- `dotnet build` de `PristonTale.GltfExport` passou com 0 warnings e 0 errors. A exportação gerou GLB e preservou SHA-256 da source. A inspeção do GLB reportou 1 cena, 2 meshes, 263 materiais, 262 imagens, 0 animações e 0 skins, sem erros de estrutura JSON/BIN/referências.
- A textura `tem_wall04.bmp` foi diagnosticada como ausente, associada ao **material 173 e a 1 face**. A exportação `--strict-textures` indicou `FAILED_TEXTURE_FALLBACKS`. O GLB é gerado, mas não é certificado como texturizado integralmente.
- `find app/pt_build -type f \( -iname '*.smd' -o -iname '*.smb' -o -iname '*.inx' \)` não retornou candidatos. Os writers ainda **não foram certificados contra leitores C#** a partir de artefatos de staging.

## Formatos e limitações

- `SMD`, `SMB`, `INX`: leitores do Etervale seguem ativos; **GLB/glTF é caminho de exportação**, não leitura nativa certificada no jogo.
- `SMAP`, `SCFG`, `SRES`, `SFLD`, `SGCF`, `SGRF`, `SCSP`, `SSKM`: conversores herdados integrados como ferramentas de staging. Empacotar formatos idênticos aos legados **não demonstra** consumo pelo Etervale novo.
- `SPM/SPP/SPC`, VFX e material/texture tooling: precisam de validação de leitor, gameplay e fidelidade visual conforme domínio.
- O scanner C/C++ legado foi isolado da auditoria C#. A auditoria C# atual é **textual**, não semanticamente completa e não permite excluir ativos por ausência de referências.

## Pontos pendentes / ações sugeridas

1. Recuperar `tem_wall04.bmp` por proveniência comprovada ou documentar substituição artística; não inventar arquivo, não copiar uma textura diferente só para satisfazer `--strict-textures`.
2. Produzir candidatos sintéticos ou a partir de workflows controlados em `app/pt_build`, com seus manifestos, para testar **writer → leitor C# → inspeção → runtime**.
3. Construir censo completo e versionado de assets ausentes a partir das dependências efetivamente utilizadas pelo C# (o relatório presente lista somente uma ocorrência comprovada).
4. Validar formatos de dados legados contra importadores e contratos de persistência atuais antes de publicar qualquer pack.
5. Redesenhar a UI apenas após mapear entradas, saídas, nível de evidência, erros e permissões por workflow. IA/NCNN e empacotamento de modelos ficam como frente independente.

## Achados históricos da análise inicial

A bateria inicial selecionada apresentou `166 passed, 1 failed` por mock sem `ADAPTIVE_PROFILE`; isso não comprova defeito no runtime NCNN. O verificador do pacote antigo reportou `.gitattributes` ausente e a auditoria documental apontou referência de API desatualizada. Esses problemas de desenvolvimento não são assets faltantes. Consulte o relatório original e o log de testes para detalhes.
