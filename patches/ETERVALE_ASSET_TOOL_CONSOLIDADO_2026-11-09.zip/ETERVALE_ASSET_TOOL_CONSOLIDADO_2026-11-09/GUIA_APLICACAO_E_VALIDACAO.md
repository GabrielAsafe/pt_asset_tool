# Guia de aplicação/reaplicação do Asset Tool (pacote histórico)

> **Atenção:** nas saídas de 2026-11-09 os três patches já tinham sido aplicados com sucesso em `~/Transferências/pt_asset_tool`. Este pacote é backup documental, não exige reaplicação.

## Preparação

Descompacte este dossiê em **pasta separada** para inspecionar os arquivos, não sobre a árvore de código. Para uma nova instalação, copie os três ZIPs e os três scripts de `patches/` para `~/Transferências/pt_asset_tool/patches/` (preservando os nomes).

Depois, **somente se realmente precisar aplicar/recriar a instalação**, na raiz do projeto:

```bash
cd "$HOME/Transferências/pt_asset_tool"
python3 patches/aplicar_patch_etervale.py --dry-run
python3 patches/aplicar_patch_etervale.py
python3 patches/aplicar_integracao_etervale.py --dry-run
python3 patches/aplicar_integracao_etervale.py
python3 patches/aplicar_diagnostico_texturas_etervale.py --dry-run
python3 patches/aplicar_diagnostico_texturas_etervale.py
```

Os scripts são sensíveis a conflitos e fazem backup; não substitua o código com `unzip -o` sem revisão. Execute `--dry-run` e interrompa se houver conflito. Os backups locais originais se encontram sob `patches/_backups/` e **não estão incluídos** neste dossiê.

## Verificar

```bash
cd "$HOME/Transferências/pt_asset_tool"
python3 app/pt_asset.py data-types list
python3 -m pytest -q app/dev_tests/test_data_type_migration_etervale.py
python3 -m pytest -q app/dev_tests/test_etervale_unified_bridge.py
python3 -m pytest -q app/dev_tests/test_etervale_texture_audit_bridge.py
python3 app/pt_asset.py config set-etervale-root "$HOME/Transferências/Etervale-git"
python3 app/pt_asset.py config show
python3 app/pt_asset.py etervale status
python3 app/pt_asset.py etervale source-audit
```

## Executar leitura/diagnóstico sem publicar no jogo

```bash
cd "$HOME/Transferências/pt_asset_tool"
python3 app/pt_asset.py etervale validate \
  --asset 'Field/Ricarten/village-2.smd' --execute --build

python3 app/pt_asset.py etervale export-glb \
  --asset 'Field/Ricarten/village-2.smd' \
  --output 'glb/village-2-recheck.glb' \
  --strict-textures --execute
```

É esperado que a segunda operação reporte `FAILED_TEXTURE_FALLBACKS` enquanto `tem_wall04.bmp` estiver ausente. O estágio privado do Asset Tool pode conter um GLB gerado, **mas não há certificação estrita**. A opção `--output` deve apontar para um nome novo no staging se a saída anterior já existir.

## Integridade do dossiê

```bash
cd /caminho/ETERVALE_ASSET_TOOL_CONSOLIDADO_2026-11-09
python3 verificar_integridade.py
```

## Responsabilidades

- Patches: transferem código para Asset Tool; não alteram automaticamente Etervale.
- Ferramentas de C#: continuam em `Etervale-git/tools`, vinculadas aos projetos reais.
- Relatórios: fotografias do estado comprovado em 2026-11-09.
- Não inclui executáveis compilados, modelos de IA, `assets/`, backups privados ou a source inteira do jogo.
