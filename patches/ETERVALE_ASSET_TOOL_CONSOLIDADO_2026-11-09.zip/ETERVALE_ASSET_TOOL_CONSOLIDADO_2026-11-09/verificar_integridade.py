#!/usr/bin/env python3
"""Verifica todos os arquivos listados em SHA256SUMS.txt do dossiê."""
from pathlib import Path
import hashlib
import sys

base = Path(__file__).resolve().parent
sums = base / 'SHA256SUMS.txt'
if not sums.is_file():
    sys.exit('ERRO: SHA256SUMS.txt não encontrado')
errors = []
count = 0
for line in sums.read_text(encoding='utf-8').splitlines():
    if not line.strip() or line.startswith('#'):
        continue
    expected, sep, rel = line.partition('  ')
    if not sep or len(expected) != 64:
        errors.append(f'entrada inválida: {line}')
        continue
    file = (base / rel).resolve()
    try:
        file.relative_to(base)
    except ValueError:
        errors.append(f'caminho fora da pasta: {rel}')
        continue
    if not file.is_file():
        errors.append(f'arquivo ausente: {rel}')
        continue
    actual = hashlib.sha256(file.read_bytes()).hexdigest()
    count += 1
    if actual != expected:
        errors.append(f'hash divergente: {rel}')
if errors:
    print('\n'.join(errors), file=sys.stderr)
    sys.exit(f'INTEGRIDADE: FALHA ({len(errors)} problemas; {count} arquivos lidos)')
print(f'INTEGRIDADE: OK ({count} arquivos conferidos)')
